﻿using Quebook_d.app;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Quebook_d
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] == null)
            {
                BO objBo = new BO();
                BLL objBll = new BLL();
                //objBll.sessionClose(objBo);
                Response.Redirect("ErrorPage.aspx");
            }
        }

        protected void LnkBtnLogout_Click(object sender, EventArgs e)
        {
            BO objBo = new BO();
            BLL objBll = new BLL();
            objBo.UserName = Session["user"].ToString();
            objBo.SessionClose= DateTime.Now.ToLocalTime().ToString("yyyy-MM-dd H:mm:ss");
            objBll.sessionClose(objBo);
            sessionUncheck();
            Response.Redirect("LoginPage.aspx");
        }

        private void sessionUncheck()
        {
            Session["user"] = null;
        }
    }
}