﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Quebook_d.app
{
    public class DAL
    {
        BO objBo = new BO();
        string dbConn = System.Configuration.ConfigurationManager.ConnectionStrings["awsconstring"].ConnectionString;

        public int Login(BO objBo)
        {
            MySqlConnection Conn = new MySqlConnection(dbConn);
            string SelQuery = "select count(*) from devr.userDtl  where username='" + objBo.UserName + "' and passkey='" + objBo.AccKey + "'";
            MySqlCommand Command = new MySqlCommand(SelQuery, Conn);
            int Reader;
            Conn.Open();
            Reader = Convert.ToInt32(Command.ExecuteScalar());
            int count = Reader;
            return count;
        }

        public string Signup(BO objBo)
        {
            string SelQuery = "select count(*) from devr.userDtl where username='" + objBo.UserName + "'";
            MySqlConnection Conn = new MySqlConnection(dbConn);
            Conn.Open();
            MySqlCommand Command = new MySqlCommand(SelQuery, Conn);
            int count;
            string status;
            count = Convert.ToInt32(Command.ExecuteScalar());
            if (count > 0)
            {
                count = 0;
                status = "exists";
            }
            else
            {
                string InsQuery = "insert into devr.userDtl(username,passkey,email) values('" + objBo.UserName + "','" + objBo.AccKey + "','" + objBo.Email + "')";
                MySqlCommand Command1 = new MySqlCommand(InsQuery, Conn);
                count = Convert.ToInt32(Command1.ExecuteNonQuery());
                if (count > 0)
                {
                    status = "inserted";
                }
                else
                {
                    status = "failed";
                }
            }
            return status;
        }

        public int StartSession(BO objBo)
        {
            MySqlConnection Conn = new MySqlConnection(dbConn);
            Conn.Close();
            string SelQuery = "select incount from devr.users where username='" + objBo.UserName + "'";
            MySqlCommand Command = new MySqlCommand(SelQuery, Conn);
            Conn.Open();
            objBo.SessionCount = Convert.ToInt32(Command.ExecuteScalar());
            int addCount = objBo.SessionCount + 1;
            string UpdQuery = "update devr.users set last_login='" + objBo.SessionStart + "',incount='" + addCount + "' where username='" + objBo.UserName + "'";
            MySqlCommand Command1 = new MySqlCommand(UpdQuery, Conn);
            int Reader = 0;
            Reader = Command1.ExecuteNonQuery();
            int count = Reader;
            return count;
        }

        public int CloseSession(BO objBo)
        {

            MySqlConnection Conn = new MySqlConnection(dbConn);
            Conn.Close();
            string UpdQuery = "update devr.users set last_logiout='" + objBo.SessionClose+ "' where username='" + objBo.UserName + "'";
            Conn.Open();
            MySqlCommand Command = new MySqlCommand(UpdQuery, Conn);
            int Reader;
            Reader = Convert.ToInt32(Command.ExecuteScalar());
            int count = Reader;
            return count;
        }
    }
}