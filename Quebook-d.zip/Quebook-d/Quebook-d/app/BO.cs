﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Quebook_d.app
{
    public class BO
    {
        //Page Load items//

        private int _sessionCount;
        private string _sessionStart;
        private string _sessionClose;
        private string _status;
        private string _userName;
        private string _accKey;
        private string _email;

        public int SessionCount
        {
            get { return _sessionCount; }
            set { _sessionCount = value; }
        }
        public string SessionStart
        {
            get { return _sessionStart; }
            set { _sessionStart = value; }
        }
        public string SessionClose
        {
            get { return _sessionClose; }
            set { _sessionClose = value; }
        }
        public string Status
        {
            get { return _status; }
            set { _status = value; }
        }
        public string UserName
        {
            get { return _userName; }
            set { _userName = value; }
        }
        public string AccKey
        {
            get { return _accKey; }
            set { _accKey = value; }
        }
        public string Email
        {
            get { return _email; }
            set { _email = value; }
        }
    }
}