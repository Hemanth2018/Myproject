﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Quebook_d.app
{
    public partial class ErrorPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            BO objBo = new BO();
            BLL objBll = new BLL();
            objBo.Status = "N";
            LblErr.Text = "Session Expired!";
            LblErrBdy.Text = "Click <a href='LoginPage.aspx'>here</a> to login.";
         
        }
    }
}