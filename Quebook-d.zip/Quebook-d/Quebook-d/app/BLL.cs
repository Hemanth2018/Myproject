﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
namespace Quebook_d.app
{
    public class BLL
    {
        DAL objDal = new DAL();
        BO objBo = new BO();

        public int userValidation(BO objBo)
        {
            int result = objDal.Login(objBo);

            return result;
        }
        public string userSignup(BO objBo)
        {
            string result = objDal.Signup(objBo);

            return result;
        }
        public int sessionStart(BO objBo)
        {
            int result = objDal.StartSession(objBo);

            return result;
        }
        public int sessionClose(BO objBo)
        {
            int result = objDal.CloseSession(objBo);

            return result;
        }
    }
}