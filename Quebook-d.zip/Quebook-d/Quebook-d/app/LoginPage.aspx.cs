﻿using System;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;
using System.Net;
using System.Security.Cryptography;
using System.IO;
using System.Text;

namespace Quebook_d.app
{
    public partial class lgn_bkp : System.Web.UI.Page
    {
        BLL objBLL = new BLL();
        BO objBo = new BO();
        protected void Page_Load(object sender, EventArgs e)
        {

            LblErr.Visible = false;
            LoginSec.Visible = true;
            SignupSec.Visible = false;
        }

        protected void Btnlogin_Click(object sender, EventArgs e)
        {

            int rows;
            BLL objBLL = new BLL();
            BO objBo = new BO();
            objBo.UserName = Txtuid.Text;
            objBo.AccKey = Encrypt(Txtkey.Text.Trim());
            rows = objBLL.userValidation(objBo);
            LblErr.Visible = false;
            if (rows > 0)
            {
                sessionCheck();
                objBo.SessionStart = DateTime.Now.ToLocalTime().ToString("yyyy-MM-dd H:mm:ss");
                objBLL.sessionStart(objBo);
                Response.Redirect("HomePage.aspx");

            }
            else
            {
                if (Txtuid.Text != "" && Txtkey.Text != "")
                {
                    Response.Write("<script>alert('Invalid credentials');</script>");
                }
            }
        }
        protected void LnkBtnNxt_Click(object sender, EventArgs e)
        {
            LoginSec.Visible = false;
            SignupSec.Visible = true;
            LnkBtnfrgtpwd.Visible = true;
            LnkBtnSignup.Visible = true;
            menu.Visible = false;

        }

        protected void LnkBtnPrev_Click(object sender, EventArgs e)
        {
            Response.Redirect("LoginPage.aspx");
        }

        protected void BtnSignup_Click(object sender, EventArgs e)
        {
            LoginSec.Visible = false;
            string result;
            BLL objBLL = new BLL();
            BO objBo = new BO();
            objBo.UserName = TxtUsrname.Text;
            objBo.AccKey = this.Encrypt(TxtPwd.Text.Trim());
            objBo.Email = TxtEmail.Text;
            result = objBLL.userSignup(objBo);
            if (result == "exists")
            {
                SignupSec.Visible = true;
                LblErr1.Visible = true;
                LblErr1.Text = "*Username taken!";
                TxtUsrname.BackColor = System.Drawing.Color.Red;
                TxtUsrname.Focus();
                LblErr1.ForeColor = System.Drawing.Color.Red;
            }
            else if (result == "inserted")
            {
                
                SignupSec.Visible = true;
                TxtUsrname.Visible = false;
                TxtPwd.Visible = false;
                TxtCnfpwd.Visible = false;
                TxtEmail.Visible = false;
                BtnSignup.Visible = false;
                SignupCrdHdr.Visible = false;
                LblErr1.Visible = true;
                LnkBtnPrev.Visible = false;
                SendEmail();
                Response.Write("<script>alert('Registered successfully!');</script>");

            }
            else
            {
                if (result == "failed")
                {
                    SignupCrdHdr.Visible = false;
                    signupSect.Visible = false;
                    LblErr1.Visible = true;
                    LblErr1.Text = "Please try again after sometime! go to <a href='LoginPage.aspx' style='color:blue'>Home</a>";
                    LblErr1.ForeColor = System.Drawing.Color.Brown;
                }
                else
                {
                    SignupSec.Visible = true;
                    LblErr1.Visible = true;
                    LblErr1.Text = "Server busy!";
                    LblErr1.ForeColor = System.Drawing.Color.Purple;
                }
            }
        }
        private void sessionCheck()
        {
            objBo.UserName= Txtuid.Text;
            Session["user"] = objBo.UserName;
        }
        private string Encrypt(string clearText)
        {
            string EncryptionKey = "MAKV2SPBNI99212";
            byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    clearText = Convert.ToBase64String(ms.ToArray());
                }
            }
            return clearText;

        }

        private string Decrypt(string cipherText)
        {
            string EncryptionKey = "MAKV2SPBNI99212";
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    cipherText = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return cipherText;
        }

        private void SendEmail()
        {
            BO objBo = new BO();
            objBo.UserName = TxtUsrname.Text;
            objBo.Email = TxtEmail.Text;
            byte[] bytes = Encoding.Default.GetBytes(objBo.Email);
            string Femail = Encoding.ASCII.GetString(bytes);
            MailMessage mailMessage = new MailMessage();
            mailMessage.From = new MailAddress("developer@w-quebook.tk");
            mailMessage.To.Add(new MailAddress(Encoding.UTF8.GetString(bytes)));
            mailMessage.CC.Add(new MailAddress("k.hemanth007@yahoo.in"));
            mailMessage.Subject = "Account services";
            mailMessage.Body = "<h1>Welcome to the developers world! your account has been create.</h1> <br/><p></b>Your username is '" + objBo.UserName + "'</b></p>.<p>Please use below link to login.</p><br/>" +
                "<a href='http://w-quebook.tk/app/LoginPage.aspx'>Quebook Login</a><br/><p>Thanks,<br/><p>Hemanth Kumar(developer)</p>";
            mailMessage.IsBodyHtml = true;
            mailMessage.Headers.Add("X-SES-CONFIGURATION-SET", "ConfigSet");
            string username = "AKIAICWFDPUVJZJQBDNQ";
            string pwd = "ArQB7UhblKTeTlnLLSbIzqfJmKC+ZMJ0uj/LKcsWLXtE";
            string Host = "email-smtp.us-east-1.amazonaws.com";
            int Port = 587;
            using (var client = new System.Net.Mail.SmtpClient(Host, Port))
            {
                client.Credentials =
                 new NetworkCredential(username, pwd);
                client.EnableSsl = true;
                try
                {
                    client.Send(mailMessage);
                }

                catch (System.FormatException)
                {
                    //SignupSec.Visible = true;
                    //LblErr1.Visible = true;
                    //LblErr1.Text = "*Please enter a valid email address!";
                    //TxtEmail.BackColor = System.Drawing.Color.Gray;
                    //TxtEmail.Focus();
                    //LblErr1.ForeColor = System.Drawing.Color.Red;

                }

            }
        }

    }
}
