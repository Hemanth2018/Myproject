﻿
var x = window.matchMedia("(max-width: 634px)")
y.addListener(openNav)
openNav(x) // Call listener function at run time
x.addListener(openNav)


function openNav(x) {
    if (x.matches) {
        document.getElementById("sidenavg").style.width = "100%";
        document.getElementById("sidenavg").style.marginRight = "0px";
        document.getElementById("LoginSec").style.visibility = "hidden";
        document.getElementById("SignupSec").style.width = "0px";
        //document.getElementById("LoginSec").style.webkitTransitionDelay = "hidden 5s";
        //document.getElementById("LoginSec").style.transition = "hidden 5s";
        //document.getElementById("LoginSec").style.marginRight = "240px";
        //document.getElementById("SignupSec").style.marginRight = "240px";
        //document.getElementById("sidenavg").style.opacity = "1";
        //document.getElementById("LoginSec").onclick = function () {
        //    this.style.visibility = "hidden";
    }
    else {
        document.getElementById("sidenavg").style.width = "240px";
        document.getElementById("sidenavg").style.height = "100%";
        //document.getElementById("LoginSec").style.webkitTransitionDelay = "hidden 5s";
        //document.getElementById("LoginSec").style.transition = "hidden 5s";
    }

}

function closeNav(x) {
    if (x.matches) {
        document.getElementById("sidenavg").style.width = "0px";
        document.getElementById("LoginSec").style.visibility = "visible";
        document.getElementById("SignupSec").style.visibility = "visible";
        //document.getElementById("LoginSec").style.marginRight = "0px";
        // document.getElementById("SignupSec").style.marginRight = "0px";
    }
    else {
        document.getElementById("sidenavg").style.width = "0px";
        document.getElementById("sidenavg").style.height = "0%";
        // document.getElementById("LoginSec").style.marginRight = "0px";
        //document.getElementById("SignupSec").style.marginRight = "0px";
    }
}



function refreshPage() {
    location.reload();
    document.getElementById("sidenavg").style.visibility = "visible";
}

$(document).ready(function () {
    $("#BtnSignup").click(function () {
        $("#myModal").modal();
    });
});